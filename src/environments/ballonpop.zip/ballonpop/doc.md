Encoding état de jeu : 
- score de chaque colonne,
- nombre de breaks,
- nombre de rerolls restants
- resultat du dernier jet de dés

Encoding action :
- indice des dés gardés
- binaire indiquant si on reroll ou non

output :




MO-IS-MCTS on ballonpop!